var moncanvas=document.getElementById('canv');
	var ctx=moncanvas.getContext('2d');
		
	ctx.lineWidth=17;
	ctx.lineCap='round';
	function degTorad(degree){
		var factor = Math.PI/180;
		return degree*factor;
	}
	function renderTime(){
		var now = new Date();
		var today = now.toDateString();
		var time = now.toLocaleTimeString();
		var hours = now.getHours();
		var minutes = now.getMinutes();
		var seconds  = now.getSeconds();
		var millisecondes  = now.getMilliseconds();
		var newSeconds = seconds + (millisecondes/1000);

		// Background


		ctx.fillStyle='333333';
		ctx.fillRect(0,0,300,300);
		ctx.fill();
		
		// Hours
		ctx.beginPath();
		ctx.strokeStyle="#341f97";
		ctx.arc(150,150,80,degTorad(270),degTorad((hours*15)-90));
		ctx.stroke();



		
		// Minutes
		ctx.beginPath();
		ctx.arc(150,150,100,degTorad(270),degTorad((minutes*6)-90));
		ctx.strokeStyle="#ff9f43";
		ctx.stroke();


		//seconds
		ctx.beginPath();
		ctx.strokeStyle="#10ac84";
		ctx.arc(150,150,120,degTorad(270),degTorad((newSeconds*6)-90));
		ctx.stroke();

		ctx.save();
		//Time
		ctx.font="25px Corbel";
		ctx.fillStyle="#30336b";
		ctx.fillText(time,110,150);
		
		ctx.restore();

		
	} 
	

	setInterval(renderTime,40);
	
	